## Version 0.8 | Change Log

-   Separation of programming languages ​​for better understanding by developers **(+)**

---

**Description:**
**This version doesn't change anything** compared to the previous version (V0.7), we bring it to make the code more organized and developers can read it better!!

_If you want to modify or publish it, please contact me. Please DO NOT COPY THE PROJECT and if you publish a modified version, leave credits._

Developer Email: gregcontact.github@gmail.com
