Version 0.6 | Change Log
---
* Bugs fixes. (-)
* Backgroud added. (+)
* Frequency Calculator added. (+)
* Code improvement and more performance. (+)
* Graphical improvement of the interface using CSS. (+)
----
Description: In version 0.5 of the “School-Tools” project, the “Menu Update” update arrived, which improved the interface. But we had to bring forward version 0.6 because there were bugs in the code, we thought it would be better to also minimally adjust the graphical interface.

If you want to modify or publish it, please contact me. Please DO NOT COPY THE PROJECT and if you publish a modified version, leave credits.

[Official GitHub](https://github.com/GregSaid/-Quarterly-Calculator)
Developer Email: gregcontact.github@gmail.com